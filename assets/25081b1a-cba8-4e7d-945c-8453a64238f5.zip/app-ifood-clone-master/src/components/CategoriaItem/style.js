import styled from 'styled-components';


export const CategoriaView = styled.View`

        margin-left: 20px;
        align-items: center;

`

export const CategoriaFoto = styled.Image`

`

export const CategoriaTexto = styled.Text`

    margin-top:5px;

`
